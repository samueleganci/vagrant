#!/bin/bash

echo "APT provisioning - begin"
sudo apt-get update -y
echo "APT provisioning - end"
